package eu.monnetproject.framework.services.deposgi;

import eu.monnetproject.framework.services.Service2;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator {

    public void start(BundleContext context) throws Exception {
        context.registerService(Service2.class.getName(), new Service2() {

            @Override
            public String getName() {
                return "OSGi";
            }
        }, null);
    }

    public void stop(BundleContext context) throws Exception {
        // TODO add deactivation code here
    }

}
