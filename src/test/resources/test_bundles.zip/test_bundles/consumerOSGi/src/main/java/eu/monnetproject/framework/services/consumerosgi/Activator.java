package eu.monnetproject.framework.services.consumerosgi;

import eu.monnetproject.framework.services.Service1;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTracker;
import org.osgi.util.tracker.ServiceTrackerCustomizer;

public class Activator implements BundleActivator {

    @Override
    public void start(final BundleContext context) throws Exception {
        new ServiceTracker(context, Service1.class.getName(), new ServiceTrackerCustomizer() {

            @Override
            public Object addingService(ServiceReference sr) {
                System.err.println(((Service1)context.getService(sr)).sayHello("OSGi"));
                return null;
            }

            @Override
            public void modifiedService(ServiceReference sr, Object o) {
            }

            @Override
            public void removedService(ServiceReference sr, Object o) {
            }
        }).open();
        System.err.println("Starting OSGi consumer");
    }

    @Override
    public void stop(BundleContext context) throws Exception {
    }

}
